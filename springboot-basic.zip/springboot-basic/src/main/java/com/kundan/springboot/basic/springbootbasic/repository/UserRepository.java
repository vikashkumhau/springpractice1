package com.kundan.springboot.basic.springbootbasic.repository;



import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.kundan.springboot.basic.springbootbasic.entity.UserEntity;
@Repository
//public interface UserRepository extends CrudRepository<UserEntity, Long> 
public interface UserRepository extends PagingAndSortingRepository<UserEntity, Long>
{
   /*
    * JPA provid the CrudRepository to do the crud operation . if u want to use own ur method in that case u can define 
    * the method in side the UserRepository interface class. 
    * u should alway use the meaning ful name example
    * findByEmail() that means find after that By is mandatory after that Entity class property name(email) 
    */
	
	UserEntity findByEmail(String email);  
	UserEntity findByUserId(String userId);
	/*UserEntity findUserByEmailVerificationToken(String token); */
	
	
}
