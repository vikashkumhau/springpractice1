package com.kundan.springboot.basic.springbootbasic.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kundan.springboot.basic.springbootbasic.domain.dto.AddressDTO;
import com.kundan.springboot.basic.springbootbasic.domain.dto.UserDto;
import com.kundan.springboot.basic.springbootbasic.domain.response.ErrorMessages;
import com.kundan.springboot.basic.springbootbasic.entity.UserEntity;
import com.kundan.springboot.basic.springbootbasic.exception.UserServiceException;
import com.kundan.springboot.basic.springbootbasic.repository.UserRepository;
import com.kundan.springboot.basic.springbootbasic.service.UserService;
import com.kundan.springboot.basic.springbootbasic.utils.Utils;
@Service
public class UserServiceImpl implements UserService {
	
	private static Logger logger=LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private Utils utils;
	
	
	
	
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
    @Transactional
	public UserDto createUser(UserDto dto) {
		logger.info("UserServiceImpl.............createUser");
		if(dto.getEmail()!=null)
		{
		//UserEntity entity=userRepository.findByEmail(dto.getEmail());
		if( userRepository.findByEmail(dto.getEmail())!=null)
		{
			throw new RuntimeException("record already exist"); 
		}
		}
		
		// approach 2
		
		for(int i=0;i<dto.getAddresses().size();i++)
		{
			AddressDTO address = dto.getAddresses().get(i);
			address.setUserDetails(dto);
			address.setAddressId(utils.generateAddressId(30));
			dto.getAddresses().set(i, address);
		}
		ModelMapper modelMapper = new ModelMapper();
		UserEntity userEntity = modelMapper.map(dto, UserEntity.class);
		String publicUserId = utils.generateUserId(30);
		userEntity.setUserId(publicUserId);
		userEntity.setEncryptedPassword(bCryptPasswordEncoder.encode(dto.getPassword()));
		UserEntity storedUserDetails = userRepository.save(userEntity);
		UserDto returnValue  = modelMapper.map(storedUserDetails, UserDto.class);
		logger.info("doneeeeeeeeeeeee");
        // approach1
		/*UserEntity userEntity=new UserEntity();
		BeanUtils.copyProperties(dto, userEntity);
		userEntity.setEncryptedPassword(bCryptPasswordEncoder.encode(dto.getPassword()));
		userEntity.setUserId(utils.generateUserId(30));
		UserEntity storedEntity=userRepository.save(userEntity);
		UserDto returnValue=new UserDto();
		BeanUtils.copyProperties(storedEntity, returnValue);
		logger.info("returnValue>>>>>>>>>>"+returnValue);*/
		

		return returnValue;
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		System.out.println("loadUserByUsername...................");
		UserEntity userEntity = userRepository.findByEmail(email);

		if (userEntity == null)
			throw new UsernameNotFoundException(email);
		
		/*return new User(userEntity.getEmail(), userEntity.getEncryptedPassword(), 
				userEntity.getEmailVerificationStatus(),
				true, true,
				true, new ArrayList<>());*/

		return new User(userEntity.getEmail(), userEntity.getEncryptedPassword(), new ArrayList<>());
	}

	@Override
	public UserDto getUser(String email) {
		UserEntity userEntity = userRepository.findByEmail(email);
		

		if (userEntity == null)
			throw new UsernameNotFoundException(ErrorMessages.NO_RECORD_FOUND.getErrorMessage());

		UserDto returnValue = new UserDto();
		BeanUtils.copyProperties(userEntity, returnValue);
 
		return returnValue;
	}
	
	@Override
	public UserDto getUserByUserId(String userId) {
		UserDto returnValue = new UserDto();
		UserEntity userEntity = userRepository.findByUserId(userId);

		if (userEntity == null)
			throw new UsernameNotFoundException("User with ID: " + userId + " not found");

		BeanUtils.copyProperties(userEntity, returnValue);

		return returnValue;
	}

	@Override
	public UserDto updateUser(String id,UserDto dto) {
		UserDto returnValue = new UserDto();

		UserEntity userEntity = userRepository.findByUserId(id);

		if (userEntity == null)
			throw new UserServiceException(ErrorMessages.NO_RECORD_FOUND.getErrorMessage());

		userEntity.setFirstName(dto.getFirstName());
		userEntity.setLastName(dto.getLastName());

		UserEntity updatedUserDetails = userRepository.save(userEntity);
		//returnValue = new ModelMapper().map(updatedUserDetails, UserDto.class);
		BeanUtils.copyProperties(updatedUserDetails, returnValue);

		return returnValue;
	}
	
	@Transactional
	@Override
	public void deleteUser(String userId) {
		UserEntity userEntity = userRepository.findByUserId(userId);

		if (userEntity == null)
			throw new UserServiceException(ErrorMessages.NO_RECORD_FOUND.getErrorMessage());

		userRepository.delete(userEntity);

	}
	
	@Override
	public List<UserDto> getUsers(int page, int limit) {
		List<UserDto> returnValue = new ArrayList<>();
		
		if(page>0) page = page-1;
		
		Pageable pageableRequest = PageRequest.of(page, limit);
		
		Page<UserEntity> usersPage = userRepository.findAll(pageableRequest);
		List<UserEntity> users = usersPage.getContent();
		
        for (UserEntity userEntity : users) {
            UserDto userDto = new UserDto();
            BeanUtils.copyProperties(userEntity, userDto);
            returnValue.add(userDto);
        }
		
		return returnValue;
	}

}
