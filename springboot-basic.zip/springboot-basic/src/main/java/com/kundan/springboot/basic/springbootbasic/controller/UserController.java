package com.kundan.springboot.basic.springbootbasic.controller;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.hateoas.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kundan.springboot.basic.springbootbasic.domain.UserDetailsRequestModel;
import com.kundan.springboot.basic.springbootbasic.domain.dto.AddressDTO;
import com.kundan.springboot.basic.springbootbasic.domain.dto.UserDto;
import com.kundan.springboot.basic.springbootbasic.domain.response.AddressesRest;
import com.kundan.springboot.basic.springbootbasic.domain.response.ErrorMessages;
import com.kundan.springboot.basic.springbootbasic.domain.response.OperationStatusModel;
import com.kundan.springboot.basic.springbootbasic.domain.response.RequestOperationStatus;
import com.kundan.springboot.basic.springbootbasic.domain.response.UserRest;
import com.kundan.springboot.basic.springbootbasic.exception.UserServiceException;
import com.kundan.springboot.basic.springbootbasic.service.AddressService;
import com.kundan.springboot.basic.springbootbasic.service.UserService;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@RestController
@RequestMapping("/userdetails") 
public class UserController {
	
	private Logger logger=LoggerFactory.getLogger(UserController.class);
	@Autowired
	private UserService UserService; 
	@Autowired
	private AddressService addressesService;
	
	//@RequestMapping("/getUser")
	@GetMapping(path = "/{id}",produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public UserRest getUser(@PathVariable String id) {
		
		logger.info("UserController.......................getUser..........");
		UserRest returnValue = new UserRest();

		UserDto userDto = UserService.getUserByUserId(id);
		
		//ModelMapper modelMapper = new ModelMapper();
		BeanUtils.copyProperties(userDto, returnValue);
		//returnValue = modelMapper.map(userDto, UserRest.class);

		return returnValue;
	}
	@RequestMapping(value="/createUser",method=RequestMethod.POST,consumes={ MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE },produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public UserRest createUser(@RequestBody UserDetailsRequestModel userDetails) throws Exception
	{
		logger.info("UserController.........createUser.....method");
		UserRest returnValue=new UserRest();
		/*// handling Exception approach1
		if(userDetails.getFirstName().isEmpty())
		{
			throw new Exception(ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());
		}
		// Approach 2 handling exception
		if(userDetails.getFirstName().isEmpty())
		{
			logger.info("custome Exception.............."+ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());
			throw new UserServiceException(ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());
		}*/
		/*UserDto userDto=new UserDto();
		BeanUtils.copyProperties(userDetails, userDto);*/
		ModelMapper modelMapper = new ModelMapper();
		UserDto userDto = modelMapper.map(userDetails, UserDto.class);
		UserDto createUser=UserService.createUser(userDto);
	//	BeanUtils.copyProperties(createUser, returnValue);
		returnValue = modelMapper.map(createUser, UserRest.class);
		logger.info("UserController.........calling to usermethod");
		return returnValue;
	}
	
	@PutMapping(path = "/{id}", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public UserRest updateUser(@PathVariable String id, @RequestBody UserDetailsRequestModel userDetails) {
		logger.info("updateUser.....method is calling");
		UserRest returnValue = new UserRest();

		UserDto userDto = new UserDto();
		//userDto = new ModelMapper().map(userDetails, UserDto.class);
		BeanUtils.copyProperties(userDetails, userDto);
		UserDto updateUser = UserService.updateUser(id, userDto);
		//returnValue = new ModelMapper().map(updateUser, UserRest.class);
		BeanUtils.copyProperties(updateUser, returnValue);

		return returnValue;
	}
	
	//@RequestMapping(value="/deleteUser",method=RequestMethod.DELETE)
	@DeleteMapping(path = "/{id}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public OperationStatusModel deleteUser(@PathVariable String id) {
		logger.info("deleteUser.....method is calling");
		OperationStatusModel returnValue = new OperationStatusModel();
		returnValue.setOperationName(RequestOperationName.DELETE.name());

		UserService.deleteUser(id);

		returnValue.setOperationResult(RequestOperationStatus.SUCCESS.name());
		return returnValue;
	}
	//http://localhost:8080/userdetails?page=0&limit=50
	@GetMapping(produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public List<UserRest> getUsers(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "3") int limit) {
		List<UserRest> returnValue = new ArrayList<>();

		List<UserDto> users = UserService.getUsers(page, limit);
		   
		/*Type listType = new TypeToken<List<UserRest>>() {
		}.getType();
		returnValue = new ModelMapper().map(users, listType);*/

		for (UserDto userDto : users) {
			UserRest userModel = new UserRest();
			BeanUtils.copyProperties(userDto, userModel);
			returnValue.add(userModel);
		}

		return returnValue;
	}
	
	@GetMapping(path = "/{id}/addresses",produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE, "application/hal+json" })
	public List<AddressesRest> getUserAddresses(@PathVariable String id) {
		
		logger.info("UserController.......................getUserAddresses..........");
		List<AddressesRest> addressesListRestModel = new ArrayList();

		List<AddressDTO> addressesDTO = addressesService.getAddresses(id);
		if (addressesDTO != null && !addressesDTO.isEmpty()) {
		Type listType = new TypeToken<List<AddressesRest>>() {
		}.getType();
		addressesListRestModel = new ModelMapper().map(addressesDTO, listType);
		
		for (AddressesRest addressRest : addressesListRestModel) {
			Link addressLink = linkTo(methodOn(UserController.class).getUserAddress(id, addressRest.getAddressId()))
					.withSelfRel();
			addressRest.add(addressLink);

			Link userLink = linkTo(methodOn(UserController.class).getUser(id)).withRel("user");
			addressRest.add(userLink);
		}
		}
		
		
		

		return addressesListRestModel;
	}
	
	
	@GetMapping(path = "/{userId}/addresses/{addressId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE, "application/hal+json" })
	public AddressesRest getUserAddress(@PathVariable String userId, @PathVariable String addressId) {

		AddressDTO addressesDto = addressesService.getAddress(addressId);

		ModelMapper modelMapper = new ModelMapper();
		Link addressLink = linkTo(methodOn(UserController.class).getUserAddress(userId, addressId)).withSelfRel();
		Link userLink = linkTo(UserController.class).slash(userId).withRel("user");
		Link addressesLink = linkTo(methodOn(UserController.class).getUserAddresses(userId)).withRel("addresses");

		AddressesRest addressesRestModel = modelMapper.map(addressesDto, AddressesRest.class);

		addressesRestModel.add(addressLink);
		addressesRestModel.add(userLink);
		addressesRestModel.add(addressesLink);

		return addressesRestModel;
	}

}
