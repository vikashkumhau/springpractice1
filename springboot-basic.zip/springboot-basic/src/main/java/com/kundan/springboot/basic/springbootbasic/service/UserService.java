package com.kundan.springboot.basic.springbootbasic.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.kundan.springboot.basic.springbootbasic.domain.dto.UserDto;

public interface UserService extends UserDetailsService {
	
	
	public UserDto createUser(UserDto dto);
	UserDto getUser(String email);
	public UserDto getUserByUserId(String userId);
	public UserDto updateUser(String id ,UserDto dto);
	public void deleteUser(String userId);
	List<UserDto> getUsers(int page, int limit);
	

}
