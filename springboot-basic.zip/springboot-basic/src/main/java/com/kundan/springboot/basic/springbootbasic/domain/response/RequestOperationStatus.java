package com.kundan.springboot.basic.springbootbasic.domain.response;

public enum RequestOperationStatus {
	ERROR, SUCCESS
}
