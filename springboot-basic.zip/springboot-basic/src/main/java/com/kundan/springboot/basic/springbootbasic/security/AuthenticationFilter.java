package com.kundan.springboot.basic.springbootbasic.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;



import com.fasterxml.jackson.databind.ObjectMapper;
import com.kundan.springboot.basic.springbootbasic.context.SpringApplicationContext;
import com.kundan.springboot.basic.springbootbasic.domain.UserLoginRequestModel;
import com.kundan.springboot.basic.springbootbasic.domain.dto.UserDto;
import com.kundan.springboot.basic.springbootbasic.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class AuthenticationFilter extends UsernamePasswordAuthenticationFilter {
	
	private Logger logger=LoggerFactory.getLogger(AuthenticationFilter.class);
    private final AuthenticationManager authenticationManager;
    
    private String contentType;
 
    public AuthenticationFilter(AuthenticationManager authenticationManager) {
    	logger.info("AuthenticationFilter...............constructor");
        this.authenticationManager = authenticationManager;
    }
    
    @Override
    public Authentication attemptAuthentication(HttpServletRequest req,
                                                HttpServletResponse res) throws AuthenticationException {
    	logger.info("AuthenticationFilter...............attemptAuthentication");
        try {
        	
        	contentType = req.getHeader("Accept");
        	// json payload create the object loginModel wrapper class  with the help of HttpservletRequest.
            UserLoginRequestModel creds = new ObjectMapper()
                    .readValue(req.getInputStream(), UserLoginRequestModel.class);
            logger.info("creds::::>>>>"+creds);
            // authenticationManger will be authenticate the username and password  which is given by user
           //  when we call authenticationManager.authenticate() method internaly serviceImpl class  loadUserByUsername () will call to
            // fetch user record from db.
            return authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            creds.getEmail(),
                            creds.getPassword(),
                            new ArrayList<>())
            );
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    // when username and password matched after that below (successfulAuthentication) method will call if username and password are not matched
    // then below method will not call . in this method we are getting username from authentication object . jsonWebToken is responsible to add the 
    // token in response object sothat client easly see the response . in this token we are adding username , expiration details, authentication prefix 
    // so......on  that means we are adding token as header response
    // client need to received this response token from header  if u want to communicate with projected resource (all resouce , update resources...)
   // need to communicate with api in that case need to include the same token in header value into request otherwise resquest unauthorized .
    
    @Override
    protected void successfulAuthentication(HttpServletRequest req,
                                            HttpServletResponse res,
                                            FilterChain chain,
                                            Authentication auth) throws IOException, ServletException {
    	 logger.info("successfulAuthentication>>>>>>");
        
        String userName = ((User) auth.getPrincipal()).getUsername();  
        logger.info("username>>>>>>"+userName);
        
        String token = Jwts.builder()
                .setSubject(userName)
                .setExpiration(new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS512, SecurityConstants.getTokenSecret())
                .compact();
       UserService userService = (UserService)SpringApplicationContext.getBean("userServiceImpl");
      UserDto userDto = userService.getUser(userName);
        
        res.addHeader(SecurityConstants.HEADER_STRING, SecurityConstants.TOKEN_PREFIX + token);
        logger.info("addheader done.....");
       res.addHeader("UserID", userDto.getUserId());

    }  

}
