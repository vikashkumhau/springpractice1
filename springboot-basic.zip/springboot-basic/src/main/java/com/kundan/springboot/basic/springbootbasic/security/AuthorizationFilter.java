package com.kundan.springboot.basic.springbootbasic.security;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import io.jsonwebtoken.Jwts;

public class AuthorizationFilter extends BasicAuthenticationFilter {
	
	private static Logger logger=LoggerFactory.getLogger(AuthorizationFilter.class) ;
    
    public AuthorizationFilter(AuthenticationManager authManager) {
        super(authManager);
     }
    /*  when Httprequest made dofilterInternal method will call  because this method accepting the HttpRequest as argument
     * of doFilterInternal method. we are able to access the header request by using the header name as key.we are taking the header
     * name from the security file ya security class.  when we ar call req.getHeader(headername) after that u can get the all header value
     * like(Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqYXZhY29vbHNAeWFob28uY29tIiwiZXhwIjoxNTQwODk3Nzg4fQ.LDUmKV0O5BGJSeDvXOkA8t_u0YHLktpYMq11ru50k5KB9PdOVtcjUYwacTG-ba5z71WZ0XwErmwoJ3WLdUUg5A"")
     * String header = req.getHeader(SecurityConstants.HEADER_STRING);
     * 
     */
    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws IOException, ServletException {
    	logger.info("AuthorizationFilter......................doFilterInternal calling");
        
        String header = req.getHeader(SecurityConstants.HEADER_STRING);
        logger.info("Header value:::::::"+header);
        // if header null or token_prefix id different then return
        if (header == null || !header.startsWith(SecurityConstants.TOKEN_PREFIX)) {
        	logger.info("AuthorizationFilter......................doFilterInternal calling  header value null");
            chain.doFilter(req, res);
            return;
        }
        
        UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
        logger.info("authentication............................."+authentication);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }   
    
    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
    	
    	
        String token = request.getHeader(SecurityConstants.HEADER_STRING);
        
        logger.info("AuthorizationFilter......................getAuthentication calling"+token);
        
        if (token != null) {
            
            token = token.replace(SecurityConstants.TOKEN_PREFIX, "");
            
            String user = Jwts.parser()
                    .setSigningKey( SecurityConstants.getTokenSecret())
                    .parseClaimsJws( token )
                    .getBody()
                    .getSubject();
            
            if (user != null) {
                return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
            }
            
            return null;
        }
        
        return null;
    }
    
}
 