package com.kundan.springboot.basic.springbootbasic.utils;

import java.security.SecureRandom;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Utils {
	
	private Logger logger=LoggerFactory.getLogger(Utils.class);
	
	private final Random RANDOM = new SecureRandom();
    private final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	
    public String generateUserId(int length) {
    	logger.info("Utils...........generateUserId");
        return generateRandomString(length);
    }
    
    public String generateAddressId(int length) {
    	logger.info("Utils...........generateUserId");
        return generateRandomString(length);
    }
    
    private String generateRandomString(int length) {
    	logger.info("Utils................generateRandomString");
    	StringBuilder returnValue = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
	            returnValue.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        logger.info("returnValue................????>>>>>----"+returnValue);
        return new String(returnValue);
    }


}
