package com.kundan.springboot.basic.springbootbasic.service;

import java.util.List;

import com.kundan.springboot.basic.springbootbasic.domain.dto.AddressDTO;



public interface AddressService {
	List<AddressDTO> getAddresses(String userId);
    AddressDTO getAddress(String addressId);
}
