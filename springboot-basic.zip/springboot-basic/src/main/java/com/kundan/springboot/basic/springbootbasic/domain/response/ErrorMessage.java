package com.kundan.springboot.basic.springbootbasic.domain.response;

import java.util.Date;

public class ErrorMessage {
	private Date timestamp;
	private String message;
	private String statusCode;
	
	
	public ErrorMessage() {}
	
	

	public ErrorMessage(Date timestamp, String message, String statusCode) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.statusCode = statusCode;
	}



	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}



	public String getStatusCode() {
		return statusCode;
	}



	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
}
