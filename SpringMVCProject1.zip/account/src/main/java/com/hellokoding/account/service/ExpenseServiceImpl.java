package com.hellokoding.account.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hellokoding.account.model.Expense;
import com.hellokoding.account.repository.ExpenseRepository;

@Component
public class ExpenseServiceImpl implements ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;
    
	@Override
	public void save(Expense expense) {
		expense.getItemlist();
		expense.getReference();
		expense.getBillamount();
		expense.getCreate_dt();
		expenseRepository.save(expense);
	}
	
	@Override
	public List<Expense> findAll() {
		return expenseRepository.findAll();
	}

	@Override
	public void delete(Integer id) {
		expenseRepository.delete(id);
		
	}

	@Override
	public Expense findById(int id) {
		// TODO Auto-generated method stub
		return expenseRepository.findOne(id);
	}
}
