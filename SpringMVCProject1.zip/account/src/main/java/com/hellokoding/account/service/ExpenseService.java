package com.hellokoding.account.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.hellokoding.account.model.Expense;

@Service
public interface ExpenseService {
	void save(Expense expense);
	List<Expense> findAll();
	void delete(Integer id);
	Expense findById(int id);
}
