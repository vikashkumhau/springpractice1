package com.hellokoding.account.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.hellokoding.account.model.Expense;
import com.hellokoding.account.model.LoginHelp;
import com.hellokoding.account.model.User;
import com.hellokoding.account.service.ExpenseService;
import com.hellokoding.account.service.SecurityService;
import com.hellokoding.account.service.UserService;
//import com.hellokoding.account.validator.ExpenseValidator;
import com.hellokoding.account.validator.UserValidator;

@Controller
public class UserController {
	
	 private static String UPLOADED_FOLDER = "F://temp//";
	 private static final String EXTERNAL_FILE_PATH="F://temp//ESI_Form.pdf";
    @Autowired
    private UserService userService;
    
    @Autowired
    private ExpenseService expenseService;
    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @RequestMapping(value="/{id}/delete",method=RequestMethod.GET)
	public String deleteUser(@PathVariable("id") Integer id) {
    	System.out.println("ID:"+id);
    	expenseService.delete(id);
		
		return "redirect:/editexpense";

	}
    
    @RequestMapping(value = "/{id}/update", method = RequestMethod.GET)
	public String showUpdateUserForm(@PathVariable("id") int id, Model model) {
		Expense expenseobj = expenseService.findById(id);
		//HashMap<String,String> map=new HashMap<String,String>();
		
		//model.addAttribute("abc",list);
		
		//populateDefaultModel(model);
		return "editExpense";
	}
    @RequestMapping(value="/getreport",method=RequestMethod.GET)
    public String generateReport(Model model) {
    	model.addAttribute("expenseForm", expenseService.findAll());
    	return "getreportexpense";
    }
    
    
   @RequestMapping(value="/addexpense",method=RequestMethod.GET)
   public String addExpense(Model model) {
	   System.out.println("Fist:********");
   	model.addAttribute("expenseForm",new Expense());
   	return "addexpense";
   }
    
   @RequestMapping(value = "/addexpense", method = RequestMethod.POST)
	public String onAddingExpenses(@ModelAttribute("expenseForm") Expense expenseForm, BindingResult bindingResult, Model model) {
	   System.out.println("second:********");
	   
	  // expValidator.validate(expenseForm, bindingResult);
	   if (bindingResult.hasErrors()) {
           return "addexpense";
       }
	   model.addAttribute("expenseForm",new Expense());
    	
    	expenseService.save(expenseForm);
    	String ref=expenseForm.getReference();
    	if(null!=ref) 
    	{
    		 model.addAttribute("messege", "Item Details has been added.");
             return "addexpense";
       }
    	return "addexpense";
	}
   
   @RequestMapping(value="/editexpense",method=RequestMethod.GET)
   public String editExpense(Model model) {
   	model.addAttribute("expenseForm", expenseService.findAll());
   	return "geteditexpense";
   }
   
    @RequestMapping(value = "/loginhelp", method = RequestMethod.GET)
    public String loginhelp(Model model) {
        model.addAttribute("helpForm", new LoginHelp());

        return "loginhelp";
    }
   @RequestMapping(value = "/loginhelp", method = RequestMethod.POST)
    public String registration(@ModelAttribute("helpForm") LoginHelp helpForm, BindingResult bindingResult, Model model) {
        //userValidator.validate(userForm, bindingResult);

        if (bindingResult.hasErrors()) {
            return "loginhelp";
        }
        //userService.save(userForm);
        
       // User user=userService.findByMobileNumber(helpForm.getMobileNumber());
        
        //model.addAttribute("helpForm",user);
        
      //  System.out.println("***********MobileNumber*******"+user.getMobile()+"***"+user.getFirstname()+"***"+user.getEmail());
        
        //securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());
       // return "redirect:/welcome";
        return "resetpassword";
    }	
	@RequestMapping(value = "/registration", method = RequestMethod.GET)
    public String registration(Model model) {
        model.addAttribute("userForm", new User());

        return "registration";
    }
    
    //private Map<String, User> userDetailsMap = new HashMap<>();
    
    @RequestMapping(value = "/registration", method = RequestMethod.POST)
    public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
        userValidator.validate(userForm, bindingResult);

        if (bindingResult.hasErrors()) {
            return "registration";
        }
        userService.save(userForm);
        securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());
        return "redirect:/wcome";
    }
    
    @ModelAttribute
    public void addAttributes(Model model,User userForm) {
        model.addAttribute("firstname",userForm.getFirstname());
        model.addAttribute("lastname",userForm.getLastname());
        model.addAttribute("mobile",userForm.getMobile());
        model.addAttribute("email",userForm.getEmail());
        model.addAttribute("username",userForm.getUsername());
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(Model model, String error, String logout) {
        if (error != null)
            model.addAttribute("error", "Your username and password is invalid.");

        if (logout != null)
            model.addAttribute("message", "You have been logged out successfully.");

        return "login";
    }

    @RequestMapping(value = {"/", "/welcome"}, method = RequestMethod.GET)
    //@RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public String welcome(Model model) {
        //return "welcome";
    	return "membercenter";
    }
    
    @RequestMapping(value = {"/wcome"}, method = RequestMethod.GET)
    public String welcom(Model model) {
        return "welcome";
    
    }
    @RequestMapping(value = "/springmvc", method = RequestMethod.GET)
    public String getSpringMVC(Model model) {
        return "springMVC";
    }
    @RequestMapping(value = "/springboot", method = RequestMethod.GET)
    public String getSpringBoot(Model model) {
        return "springboot";
    }
    
    //FILE UPLOAD 
    
    @RequestMapping(value="/fileupload",method=RequestMethod.GET)  
    public ModelAndView fileuploadForm(){  
        return new ModelAndView("fileuploadform");    
    } 
    
    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public @ResponseBody
	String uploadFileHandler(@RequestParam("file") MultipartFile file,Model model) {

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
	            Files.write(path, bytes);
				return "File successfully uploaded";
			} catch (Exception e) {
				return "You failed to upload file" + e.getMessage();
			}
		} else {
			return "You failed to upload file because the file was empty.";
		}
	}
    
    //FILE DOWNLOAD
    
	@RequestMapping(value = "/download/{type}", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse response, @PathVariable("type") String type) throws IOException {
		File file = null;
		System.out.println("Type"+type);
		file = new File(EXTERNAL_FILE_PATH);
		System.out.println("EXTERNAL_FILE_PATH"+EXTERNAL_FILE_PATH);
		String mimeType= URLConnection.guessContentTypeFromName(file.getName());
		System.out.println("mimeType"+mimeType);
		if(mimeType==null){
            System.out.println("mimetype is not detectable, will take default");
            mimeType = "application/octet-stream";
        }
		System.out.println("mimetype : "+mimeType);
		response.setContentType(mimeType);
		response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() +"\""));
		response.setContentLength((int)file.length());
		InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
		FileCopyUtils.copy(inputStream, response.getOutputStream());
	}
}
